summary.popiita<-function(object, ...){
out<-object
class(out)<-"summpopiita"
return(out)
}